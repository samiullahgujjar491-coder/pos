import { Request, Response } from 'express';
import { productService } from './product.service';
import { ok, created } from '../../utils/response';
import { asyncHandler } from '../../utils/asyncHandler';

export const productController = {
  list: asyncHandler(async (req: Request, res: Response) => {
    const { search, categoryId, cursor, take } = req.query;
    ok(res, await productService.list({
      search: search as string,
      categoryId: categoryId as string,
      cursor: cursor as string,
      take: take ? parseInt(take as string, 10) : undefined,
    }));
  }),
  get: asyncHandler(async (req: Request, res: Response) => {
    ok(res, await productService.getById(req.params.id));
  }),
  create: asyncHandler(async (req: Request, res: Response) => {
    created(res, await productService.create(req.body, req.user?.id));
  }),
  update: asyncHandler(async (req: Request, res: Response) => {
    ok(res, await productService.update(req.params.id, req.body), 'Updated');
  }),
  remove: asyncHandler(async (req: Request, res: Response) => {
    await productService.remove(req.params.id);
    ok(res, null, 'Deleted');
  }),
};
