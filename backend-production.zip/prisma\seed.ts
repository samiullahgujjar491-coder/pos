import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const MODULES = ['products', 'inventory', 'pos', 'purchasing', 'crm', 'reports', 'finance', 'users', 'settings'];
const ACTIONS = ['create', 'read', 'update', 'delete', 'approve', 'export'];

// Default permission sets per role (module:action). Super Admin gets everything implicitly.
const ROLE_MATRIX: Record<string, string[]> = {
  Admin: MODULES.filter((m) => m !== 'settings').flatMap((m) => ACTIONS.map((a) => `${m}:${a}`)).concat(['settings:read']),
  Manager: [
    ...['products', 'inventory', 'pos', 'reports'].flatMap((m) => ACTIONS.map((a) => `${m}:${a}`)),
    'crm:read', 'crm:create', 'crm:update', 'finance:read', 'users:read',
  ],
  Cashier: ['pos:create', 'pos:read', 'products:read', 'crm:read', 'crm:create', 'reports:read'],
  'Warehouse Staff': ['inventory:create', 'inventory:read', 'inventory:update', 'products:read', 'purchasing:read', 'purchasing:update'],
  Accountant: ['finance:create', 'finance:read', 'finance:update', 'finance:approve', 'finance:export', 'reports:read', 'reports:export', 'products:read', 'crm:read', 'purchasing:read'],
};

async function main() {
  console.log('Seeding…');

  // Permissions
  for (const module of MODULES) {
    for (const action of ACTIONS) {
      await prisma.permission.upsert({
        where: { module_action: { module, action } },
        update: {},
        create: { module, action },
      });
    }
  }
  const allPerms = await prisma.permission.findMany();
  const permId = (key: string) => {
    const [m, a] = key.split(':');
    return allPerms.find((p) => p.module === m && p.action === a)?.id;
  };

  // Roles
  const superAdmin = await prisma.role.upsert({
    where: { name: 'Super Admin' }, update: {},
    create: { name: 'Super Admin', description: 'Full system access', isSystem: true },
  });
  // Super Admin gets all permissions
  for (const p of allPerms) {
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: superAdmin.id, permissionId: p.id } },
      update: {}, create: { roleId: superAdmin.id, permissionId: p.id },
    });
  }
  for (const [name, perms] of Object.entries(ROLE_MATRIX)) {
    const role = await prisma.role.upsert({
      where: { name }, update: {}, create: { name, isSystem: true },
    });
    for (const key of perms) {
      const id = permId(key);
      if (!id) continue;
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: role.id, permissionId: id } },
        update: {}, create: { roleId: role.id, permissionId: id },
      });
    }
  }

  // Branch + warehouse + terminal
  const branch = await prisma.branch.upsert({
    where: { code: 'HQ' }, update: {},
    create: { name: 'Head Office', code: 'HQ', address: 'Lahore, Pakistan' },
  });
  const warehouse = await prisma.warehouse.upsert({
    where: { code: 'WH-MAIN' }, update: {},
    create: { name: 'Main Warehouse', code: 'WH-MAIN', branchId: branch.id },
  });
  await prisma.terminal.upsert({
    where: { code: 'POS-1' }, update: {},
    create: { name: 'Counter 1', code: 'POS-1', branchId: branch.id },
  });

  // Currencies
  await prisma.currency.upsert({
    where: { code: 'PKR' }, update: {},
    create: { code: 'PKR', name: 'Pakistani Rupee', symbol: 'Rs', exchangeRate: 100, isBase: true },
  });
  await prisma.currency.upsert({
    where: { code: 'USD' }, update: {},
    create: { code: 'USD', name: 'US Dollar', symbol: '$', exchangeRate: 27800 },
  });

  // Tax rate (GST 17%)
  const gst = await prisma.taxRate.findFirst({ where: { name: 'GST 17%' } });
  if (!gst) await prisma.taxRate.create({ data: { name: 'GST 17%', rate: 1700 } });

  // Admin user
  const adminEmail = 'eneedlyadmin@gmail.com';
  const existing = await prisma.user.findFirst({ where: { email: adminEmail } });
  if (!existing) {
    await prisma.user.create({
      data: {
        email: adminEmail,
        passwordHash: await bcrypt.hash('eneedly@123', 10),
        pinHash: await bcrypt.hash('1234', 10),
        fullName: 'System Administrator',
        roleId: superAdmin.id,
        branches: { create: [{ branchId: branch.id }] },
      },
    });
  }

  // Sample products
  const sampleProducts = [
    { name: 'Coca-Cola 500ml', sku: 'CC-500', barcode: '8964000123456', sellingPrice: 8000, costPrice: 6000 },
    { name: 'Lays Classic 50g', sku: 'LAYS-50', barcode: '8964000654321', sellingPrice: 5000, costPrice: 3800 },
    { name: 'Nestle Water 1.5L', sku: 'NW-15', barcode: '8964000111222', sellingPrice: 6000, costPrice: 4500 },
  ];
  for (const p of sampleProducts) {
    const exists = await prisma.product.findFirst({ where: { sku: p.sku } });
    if (!exists) {
      const prod = await prisma.product.create({ data: { ...p, reorderPoint: 20, reorderQty: 100 } });
      await prisma.warehouseStock.create({
        data: { warehouseId: warehouse.id, productId: prod.id, quantity: 200, avgCost: p.costPrice },
      });
    }
  }

  console.log('Seed complete. Login: admin@pos.local / Admin@123  (PIN 1234)');
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
