import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import { env } from './config/env';
import { errorHandler } from './middleware/errorHandler';
import { apiLimiter } from './middleware/rateLimiter';
import { swaggerSpec } from './config/swagger';

import authRoutes from './modules/auth/auth.routes';
import productRoutes from './modules/products/product.routes';
import userRoutes, { roleRouter } from './modules/users/user.routes';
import salesRoutes from './modules/sales/sales.routes';
import customerRoutes from './modules/customers/customer.routes';
import inventoryRoutes from './modules/inventory/inventory.routes';
import supplierRoutes from './modules/suppliers/supplier.routes';
import { reportsRouter, financeRouter } from './modules/reports/reports.routes';
import labourRoutes from './modules/labour/labour.routes';

export function createApp() {
  const app = express();
  app.use(helmet());
  app.use(cors({ origin: env.corsOrigin, credentials: true }));
  app.use(express.json({ limit: '5mb' }));

  app.get('/health', (_req, res) => res.json({ success: true, status: 'ok', timestamp: new Date() }));
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

  const v1 = express.Router();
  v1.use(apiLimiter);
  v1.use('/auth', authRoutes);
  v1.use('/products', productRoutes);
  v1.use('/users', userRoutes);
  v1.use('/roles', roleRouter);
  v1.use('/sales', salesRoutes);
  v1.use('/customers', customerRoutes);
  v1.use('/inventory', inventoryRoutes);
  v1.use('/suppliers', supplierRoutes);
  v1.use('/reports', reportsRouter);
  v1.use('/finance', financeRouter);
  v1.use('/labour', labourRoutes);

  app.use('/api/v1', v1);
  app.use((_req, res) => res.status(404).json({ success: false, message: 'Route not found', code: 'NOT_FOUND' }));
  app.use(errorHandler);
  return app;
}
