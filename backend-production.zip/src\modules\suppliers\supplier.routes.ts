import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { prisma } from '../../config/prisma';
import { ApiError } from '../../utils/ApiError';
import { z } from 'zod';
import { validate } from '../../middleware/validate';
import { auditLogger } from '../../middleware/auditLogger';

const router = Router();
router.use(authenticate, auditLogger('purchasing'));

const supplierSchema = z.object({
  body: z.object({
    name: z.string().min(1),
    contactPerson: z.string().optional(),
    email: z.string().email().optional().or(z.literal('')),
    phone: z.string().optional(),
    address: z.string().optional(),
    paymentTerms: z.string().optional(),
    leadTimeDays: z.number().int().nonnegative().default(0),
  }),
});

// SUPPLIERS CRUD
router.get('/', requirePermission('purchasing', 'read'), asyncHandler(async (req, res) => {
  const { search } = req.query;
  const suppliers = await prisma.supplier.findMany({
    where: {
      deletedAt: null,
      ...(search ? { OR: [{ name: { contains: search as string, mode: 'insensitive' } }, { phone: { contains: search as string } }] } : {}),
    },
    include: { _count: { select: { purchaseOrders: true } } },
    orderBy: { name: 'asc' },
  });
  ok(res, suppliers);
}));

router.post('/', requirePermission('purchasing', 'create'), validate(supplierSchema), asyncHandler(async (req, res) => {
  const supplier = await prisma.supplier.create({ data: { ...req.body, createdBy: req.user!.id } });
  created(res, supplier);
}));

router.put('/:id', requirePermission('purchasing', 'update'), validate(supplierSchema), asyncHandler(async (req, res) => {
  const supplier = await prisma.supplier.update({ where: { id: req.params.id }, data: req.body });
  ok(res, supplier, 'Updated');
}));

router.delete('/:id', requirePermission('purchasing', 'delete'), asyncHandler(async (req, res) => {
  await prisma.supplier.update({ where: { id: req.params.id }, data: { deletedAt: new Date() } });
  ok(res, null, 'Deleted');
}));

// PURCHASE ORDERS
const poSchema = z.object({
  body: z.object({
    supplierId: z.string().uuid(),
    expectedDate: z.string().optional(),
    notes: z.string().optional(),
    lineItems: z.array(z.object({
      productId: z.string().uuid(),
      quantity: z.number().int().positive(),
      unitCost: z.number().int().nonnegative(),
    })).min(1),
  }),
});

router.get('/orders', requirePermission('purchasing', 'read'), asyncHandler(async (req, res) => {
  const { supplierId, status } = req.query;
  const orders = await prisma.purchaseOrder.findMany({
    where: {
      deletedAt: null,
      ...(supplierId ? { supplierId: supplierId as string } : {}),
      ...(status ? { status: status as string } : {}),
    },
    include: { supplier: { select: { name: true } }, lineItems: true, _count: { select: { grns: true } } },
    orderBy: { createdAt: 'desc' },
  });
  ok(res, orders);
}));

router.post('/orders', requirePermission('purchasing', 'create'), validate(poSchema), asyncHandler(async (req, res) => {
  const { supplierId, expectedDate, notes, lineItems } = req.body;
  const subtotal = lineItems.reduce((s: number, i: any) => s + i.quantity * i.unitCost, 0);
  const po = await prisma.purchaseOrder.create({
    data: {
      poNumber: `PO-${Date.now()}`,
      supplierId,
      expectedDate: expectedDate ? new Date(expectedDate) : null,
      notes,
      subtotal,
      grandTotal: subtotal,
      createdBy: req.user!.id,
      lineItems: { create: lineItems },
    },
    include: { lineItems: true, supplier: true },
  });
  created(res, po);
}));

router.patch('/orders/:id/status', requirePermission('purchasing', 'approve'), asyncHandler(async (req, res) => {
  const { status } = req.body;
  const po = await prisma.purchaseOrder.update({
    where: { id: req.params.id },
    data: { status, ...(status === 'APPROVED' ? { approvedBy: req.user!.id } : {}) },
  });
  ok(res, po, `PO ${status}`);
}));

// GRN - Goods Received Note
router.post('/orders/:id/grn', requirePermission('purchasing', 'update'), asyncHandler(async (req, res) => {
  const po = await prisma.purchaseOrder.findUnique({ where: { id: req.params.id }, include: { lineItems: true } });
  if (!po) throw ApiError.notFound('PO not found');

  const { receivedItems, warehouseId } = req.body; // [{ productId, receivedQty, unitCost }]

  const grn = await prisma.grn.create({
    data: {
      grnNumber: `GRN-${Date.now()}`,
      poId: po.id,
      status: 'COMPLETED',
      createdBy: req.user!.id,
      lineItems: { create: receivedItems.map((i: any) => ({ productId: i.productId, receivedQty: i.receivedQty, unitCost: i.unitCost })) },
    },
  });

  // Update stock
  for (const item of receivedItems) {
    await prisma.warehouseStock.upsert({
      where: { warehouseId_productId_variantId: { warehouseId, productId: item.productId, variantId: null } },
      update: { quantity: { increment: item.receivedQty } },
      create: { warehouseId, productId: item.productId, quantity: item.receivedQty, avgCost: item.unitCost },
    });
    await prisma.stockMovement.create({
      data: { productId: item.productId, warehouseId, type: 'PURCHASE', quantity: item.receivedQty, unitCost: item.unitCost, reference: grn.id, createdBy: req.user!.id },
    });
  }

  await prisma.purchaseOrder.update({ where: { id: po.id }, data: { status: 'RECEIVED' } });
  ok(res, grn, 'GRN created, stock updated');
}));

export default router;
