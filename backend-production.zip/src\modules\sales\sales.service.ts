import { prisma } from '../../config/prisma';
import { ApiError } from '../../utils/ApiError';
import { emitInventoryChange } from '../../config/socket';

interface SaleLineInput {
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount?: number;
  taxRate?: number;
}

interface PaymentInput {
  method: string;
  amount: number;
  reference?: string;
}

interface CreateSaleInput {
  branchId: string;
  terminalId?: string;
  shiftId?: string;
  customerId?: string;
  lineItems: SaleLineInput[];
  payments: PaymentInput[];
  billDiscount?: number;
  currency?: string;
}

function generateInvoiceNo() {
  const d = new Date();
  return `INV-${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;
}

export const salesService = {
  async create(input: CreateSaleInput, userId: string) {
    const { branchId, terminalId, shiftId, customerId, lineItems, payments, billDiscount = 0, currency = 'PKR' } = input;

    const subtotal = lineItems.reduce((s, i) => s + i.unitPrice * i.quantity - (i.discount ?? 0), 0);
    const lineDiscount = lineItems.reduce((s, i) => s + (i.discount ?? 0), 0);
    const afterDiscount = Math.max(0, subtotal - billDiscount);
    const taxTotal = lineItems.reduce((s, i) => {
      const lineNet = i.unitPrice * i.quantity - (i.discount ?? 0);
      return s + Math.round((lineNet * (i.taxRate ?? 0)) / 10000);
    }, 0);
    const grandTotal = afterDiscount + taxTotal;
    const paidTotal = payments.reduce((s, p) => s + p.amount, 0);

    const sale = await prisma.sale.create({
      data: {
        invoiceNumber: generateInvoiceNo(),
        branchId,
        terminalId: terminalId ?? null,
        shiftId: shiftId ?? null,
        userId,
        customerId: customerId ?? null,
        subtotal,
        lineDiscount,
        billDiscount,
        taxTotal,
        grandTotal,
        paidTotal,
        changeDue: Math.max(0, paidTotal - grandTotal),
        status: 'COMPLETED',
        currency,
        lineItems: {
          create: lineItems.map((i) => ({
            productId: i.productId,
            description: i.description,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            discount: i.discount ?? 0,
            taxRate: i.taxRate ?? 0,
            taxAmount: Math.round((i.unitPrice * i.quantity * (i.taxRate ?? 0)) / 10000),
            lineTotal: i.unitPrice * i.quantity - (i.discount ?? 0),
          })),
        },
        payments: { create: payments },
      },
      include: { lineItems: true, payments: true },
    });

    // Decrement stock for each line item & broadcast
    const branch = await prisma.branch.findUnique({
      where: { id: branchId },
      include: { warehouses: { take: 1 } }
    });
    const defaultWarehouseId = branch?.warehouses[0]?.id;

    if (defaultWarehouseId) {
      const warehouseStock = await prisma.warehouseStock.findMany({
        where: { 
          warehouseId: defaultWarehouseId,
          productId: { in: lineItems.map((i) => i.productId) } 
        },
      });

      for (const line of lineItems) {
        let ws = warehouseStock.find((w) => w.productId === line.productId);
        
        if (!ws) {
          ws = await prisma.warehouseStock.create({
            data: {
              productId: line.productId,
              warehouseId: defaultWarehouseId,
              quantity: 0
            }
          });
        }

        await prisma.warehouseStock.update({
          where: { id: ws.id },
          data: { quantity: { decrement: line.quantity } },
        });

        await prisma.stockMovement.create({
          data: {
            productId: line.productId,
            warehouseId: defaultWarehouseId,
            type: 'SALE',
            quantity: -line.quantity,
            reference: sale.id,
            createdBy: userId,
          },
        });
        emitInventoryChange(defaultWarehouseId, { productId: line.productId, change: -line.quantity });
      }
    }

    // Loyalty points (1 point per 100 Rs = 10000 paisa)
    if (customerId) {
      const pointsEarned = Math.floor(grandTotal / 10000);
      if (pointsEarned > 0) {
        await prisma.customerLoyalty.upsert({
          where: { customerId },
          update: { pointsBalance: { increment: pointsEarned }, lifetimePoints: { increment: pointsEarned } },
          create: { customerId, pointsBalance: pointsEarned, lifetimePoints: pointsEarned },
        });
      }
    }

    return sale;
  },

  async list(branchId?: string, take = 50, cursor?: string) {
    const items = await prisma.sale.findMany({
      where: { status: { not: 'HELD' }, ...(branchId ? { branchId } : {}) },
      take: take + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { fullName: true } },
        customer: { select: { name: true } },
        payments: true,
        lineItems: true,
      },
    });
    const hasMore = items.length > take;
    return { items: hasMore ? items.slice(0, take) : items, nextCursor: hasMore ? items[take - 1].id : null };
  },

  async getById(id: string) {
    const sale = await prisma.sale.findUnique({
      where: { id },
      include: {
        lineItems: { include: { product: { select: { name: true, sku: true } } } },
        payments: true,
        customer: true,
        user: { select: { fullName: true } },
        branch: true,
      },
    });
    if (!sale) throw ApiError.notFound('Sale not found');
    return sale;
  },

  async todayStats(branchId: string) {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const end = new Date(); end.setHours(23, 59, 59, 999);
    const sales = await prisma.sale.findMany({
      where: { branchId, status: 'COMPLETED', createdAt: { gte: start, lte: end } },
      include: { lineItems: true },
    });
    const revenue = sales.reduce((s, x) => s + x.grandTotal, 0);
    const txCount = sales.length;
    const avgBill = txCount ? Math.round(revenue / txCount) : 0;
    // top products
    const productMap: Record<string, { name: string; qty: number; revenue: number }> = {};
    for (const sale of sales) {
      for (const line of sale.lineItems) {
        if (!productMap[line.productId]) productMap[line.productId] = { name: line.description, qty: 0, revenue: 0 };
        productMap[line.productId].qty += line.quantity;
        productMap[line.productId].revenue += line.lineTotal;
      }
    }
    const topProducts = Object.entries(productMap)
      .sort((a, b) => b[1].revenue - a[1].revenue)
      .slice(0, 5)
      .map(([id, v]) => ({ id, ...v }));
    return { revenue, txCount, avgBill, topProducts };
  },
};
