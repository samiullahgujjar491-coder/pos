import { Router } from 'express';
import { prisma } from '../../config/prisma';
import bcrypt from 'bcryptjs';
import { Request, Response } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { auditLogger } from '../../middleware/auditLogger';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { ApiError } from '../../utils/ApiError';
import { z } from 'zod';
import { validate } from '../../middleware/validate';

const router = Router();
router.use(authenticate, auditLogger('users'));

const createUserSchema = z.object({
  body: z.object({
    email: z.string().email(),
    password: z.string().min(6),
    pin: z.string().min(4).max(8).optional(),
    fullName: z.string().min(1),
    phone: z.string().optional(),
    roleId: z.string().uuid(),
    branchIds: z.array(z.string().uuid()).default([]),
  }),
});

router.get('/', requirePermission('users', 'read'), asyncHandler(async (_req: Request, res: Response) => {
  const users = await prisma.user.findMany({
    where: { deletedAt: null },
    select: { id: true, email: true, fullName: true, phone: true, isActive: true, role: { select: { name: true } }, lastLoginAt: true },
    orderBy: { createdAt: 'desc' },
  });
  ok(res, users);
}));

router.post('/', requirePermission('users', 'create'), validate(createUserSchema), asyncHandler(async (req: Request, res: Response) => {
  const { email, password, pin, fullName, phone, roleId, branchIds } = req.body;
  const exists = await prisma.user.findFirst({ where: { email, deletedAt: null } });
  if (exists) throw ApiError.conflict('Email already in use');
  const user = await prisma.user.create({
    data: {
      email, fullName, phone, roleId, createdBy: req.user?.id,
      passwordHash: await bcrypt.hash(password, 10),
      pinHash: pin ? await bcrypt.hash(pin, 10) : null,
      branches: { create: branchIds.map((branchId: string) => ({ branchId })) },
    },
    select: { id: true, email: true, fullName: true },
  });
  created(res, user);
}));

router.delete('/:id', requirePermission('users', 'delete'), asyncHandler(async (req: Request, res: Response) => {
  await prisma.user.update({ where: { id: req.params.id }, data: { deletedAt: new Date(), isActive: false } });
  ok(res, null, 'Deleted');
}));

export default router;

// Roles listing (read-only helper)
export const roleRouter = Router();
roleRouter.use(authenticate);
roleRouter.get('/', requirePermission('users', 'read'), asyncHandler(async (_req: Request, res: Response) => {
  const roles = await prisma.role.findMany({
    where: { deletedAt: null },
    include: { rolePermissions: { include: { permission: true } } },
  });
  ok(res, roles);
}));
