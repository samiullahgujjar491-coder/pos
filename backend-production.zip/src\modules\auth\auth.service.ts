import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'crypto';
import { prisma } from '../../config/prisma';
import { env } from '../../config/env';
import { ApiError } from '../../utils/ApiError';

type UserWithRole = Awaited<ReturnType<typeof loadUserContext>>;

function buildPermissions(
  rolePermissions: { permission: { module: string; action: string } }[],
): string[] {
  return rolePermissions.map((rp) => `${rp.permission.module}:${rp.permission.action}`);
}

async function loadUserContext(userId: string) {
  const user = await prisma.user.findFirst({
    where: { id: userId, deletedAt: null, isActive: true },
    include: {
      role: { include: { rolePermissions: { include: { permission: true } } } },
      branches: true,
    },
  });
  if (!user) throw ApiError.unauthorized('User not found or inactive');
  return user;
}

function toPayload(user: UserWithRole): Express.UserPayload {
  return {
    id: user.id,
    email: user.email,
    roleId: user.roleId,
    roleName: user.role.name,
    permissions: buildPermissions(user.role.rolePermissions),
    branchIds: user.branches.map((b) => b.branchId),
  };
}

function signTokens(payload: Express.UserPayload) {
  const accessToken = jwt.sign(payload, env.jwtSecret, {
    expiresIn: env.accessTokenTtl,
  } as jwt.SignOptions);
  const refreshToken = jwt.sign(
    { sub: payload.id, jti: randomUUID() },
    env.jwtRefreshSecret,
    { expiresIn: `${env.refreshTokenTtlDays}d` } as jwt.SignOptions,
  );
  return { accessToken, refreshToken };
}

export const authService = {
  async issue(user: UserWithRole) {
    const payload = toPayload(user);
    const { accessToken, refreshToken } = signTokens(payload);
    const expiresAt = new Date(Date.now() + env.refreshTokenTtlDays * 86400_000);
    await prisma.refreshToken.create({ data: { userId: user.id, token: refreshToken, expiresAt } });
    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    return { user: payload, accessToken, refreshToken };
  },

  async login(email: string, password: string) {
    const user = await prisma.user.findFirst({
      where: { email, deletedAt: null },
      include: {
        role: { include: { rolePermissions: { include: { permission: true } } } },
        branches: true,
      },
    });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      throw ApiError.unauthorized('Invalid credentials');
    }
    if (!user.isActive) throw ApiError.forbidden('Account disabled');
    return this.issue(user);
  },

  async pinLogin(email: string, pin: string) {
    const user = await prisma.user.findFirst({
      where: { email, deletedAt: null },
      include: {
        role: { include: { rolePermissions: { include: { permission: true } } } },
        branches: true,
      },
    });
    if (!user?.pinHash || !(await bcrypt.compare(pin, user.pinHash))) {
      throw ApiError.unauthorized('Invalid PIN');
    }
    if (!user.isActive) throw ApiError.forbidden('Account disabled');
    return this.issue(user);
  },

  async refresh(refreshToken: string) {
    let decoded: { sub: string };
    try {
      decoded = jwt.verify(refreshToken, env.jwtRefreshSecret) as { sub: string };
    } catch {
      throw ApiError.unauthorized('Invalid refresh token');
    }
    const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
    if (!stored || stored.revokedAt || stored.expiresAt < new Date()) {
      throw ApiError.unauthorized('Refresh token expired or revoked');
    }
    const user = await loadUserContext(decoded.sub);
    await prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
    return this.issue(user);
  },

  async logout(refreshToken: string) {
    await prisma.refreshToken.updateMany({
      where: { token: refreshToken, revokedAt: null },
      data: { revokedAt: new Date() },
    });
  },
};
