import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { prisma } from '../../config/prisma';
import { ApiError } from '../../utils/ApiError';
import { auditLogger } from '../../middleware/auditLogger';

const router = Router();
router.use(authenticate, auditLogger('labour'));

// ============================================================
// WORKERS
// ============================================================
router.get('/workers', asyncHandler(async (req, res) => {
  const { search, isActive } = req.query;
  const workers = await prisma.worker.findMany({
    where: {
      deletedAt: null,
      ...(isActive !== undefined ? { isActive: isActive === 'true' } : {}),
      ...(search ? { OR: [{ fullName: { contains: search as string, mode: 'insensitive' } }, { phone: { contains: search as string } }] } : {}),
    },
    include: { _count: { select: { jobAssignments: true } }, advances: { select: { amount: true } }, payments: { select: { amount: true, type: true } } },
    orderBy: { fullName: 'asc' },
  });
  const result = workers.map(w => {
    const totalAdvances = w.advances.reduce((s, a) => s + a.amount, 0);
    const totalWages = w.payments.filter(p => p.type === 'WAGE' || p.type === 'BONUS').reduce((s, p) => s + p.amount, 0);
    const totalDeductions = w.payments.filter(p => p.type === 'DEDUCTION').reduce((s, p) => s + p.amount, 0);
    return { ...w, totalAdvances, totalWages, totalDeductions, balance: totalAdvances - totalWages + totalDeductions };
  });
  ok(res, result);
}));

router.get('/workers/:id', asyncHandler(async (req, res) => {
  const worker = await prisma.worker.findFirst({ where: { id: req.params.id, deletedAt: null }, include: { jobAssignments: { include: { job: true }, orderBy: { assignedAt: 'desc' }, take: 20 }, advances: { orderBy: { paidAt: 'desc' } }, payments: { orderBy: { paidAt: 'desc' } } } });
  if (!worker) throw ApiError.notFound('Worker not found');
  ok(res, worker);
}));

router.post('/workers', asyncHandler(async (req, res) => {
  const { fullName, phone, email, cnic, skills, dailyRate, hourlyRate, address, emergencyContact } = req.body;
  const worker = await prisma.worker.create({ data: { fullName, phone, email, cnic, address, emergencyContact, skills: skills ?? [], dailyRate: Math.round((parseFloat(dailyRate) || 0) * 100), hourlyRate: Math.round((parseFloat(hourlyRate) || 0) * 100), createdBy: req.user!.id } });
  created(res, worker);
}));

router.put('/workers/:id', asyncHandler(async (req, res) => {
  const { fullName, phone, email, cnic, skills, dailyRate, hourlyRate, address, emergencyContact, isActive } = req.body;
  const worker = await prisma.worker.update({ where: { id: req.params.id }, data: { fullName, phone, email, cnic, address, emergencyContact, isActive, skills: skills ?? [], dailyRate: Math.round((parseFloat(dailyRate) || 0) * 100), hourlyRate: Math.round((parseFloat(hourlyRate) || 0) * 100) } });
  ok(res, worker, 'Updated');
}));

router.delete('/workers/:id', asyncHandler(async (req, res) => {
  await prisma.worker.update({ where: { id: req.params.id }, data: { deletedAt: new Date(), isActive: false } });
  ok(res, null, 'Deleted');
}));

// Advance CRUD
router.post('/workers/:id/advance', asyncHandler(async (req, res) => {
  const { amount, reason, jobId } = req.body;
  const advance = await prisma.workerAdvance.create({ data: { workerId: req.params.id, amount: Math.round(parseFloat(amount) * 100), reason, jobId: jobId || null, paidBy: req.user!.id } });
  ok(res, advance, 'Advance recorded');
}));

router.put('/workers/advance/:id', asyncHandler(async (req, res) => {
  const { amount, reason } = req.body;
  const advance = await prisma.workerAdvance.update({ where: { id: req.params.id }, data: { amount: Math.round(parseFloat(amount) * 100), reason } });
  ok(res, advance, 'Advance updated');
}));

router.delete('/workers/advance/:id', asyncHandler(async (req, res) => {
  await prisma.workerAdvance.delete({ where: { id: req.params.id } });
  ok(res, null, 'Advance deleted');
}));

// Payment CRUD
router.post('/workers/:id/payment', asyncHandler(async (req, res) => {
  const { amount, type, description, jobId } = req.body;
  const payment = await prisma.workerPayment.create({ data: { workerId: req.params.id, amount: Math.round(parseFloat(amount) * 100), type: type ?? 'WAGE', description, jobId: jobId || null, paidBy: req.user!.id } });
  ok(res, payment, 'Payment recorded');
}));

router.put('/workers/payment/:id', asyncHandler(async (req, res) => {
  const { amount, type, description } = req.body;
  const payment = await prisma.workerPayment.update({ where: { id: req.params.id }, data: { amount: Math.round(parseFloat(amount) * 100), type, description } });
  ok(res, payment, 'Payment updated');
}));

router.delete('/workers/payment/:id', asyncHandler(async (req, res) => {
  await prisma.workerPayment.delete({ where: { id: req.params.id } });
  ok(res, null, 'Payment deleted');
}));

// Worker statement
router.get('/workers/:id/statement', asyncHandler(async (req, res) => {
  const worker = await prisma.worker.findFirst({ where: { id: req.params.id, deletedAt: null } });
  if (!worker) throw ApiError.notFound('Worker not found');
  const [advances, payments, jobs] = await Promise.all([
    prisma.workerAdvance.findMany({ where: { workerId: req.params.id }, orderBy: { paidAt: 'desc' } }),
    prisma.workerPayment.findMany({ where: { workerId: req.params.id }, orderBy: { paidAt: 'desc' } }),
    prisma.jobAssignment.findMany({ where: { workerId: req.params.id }, include: { job: { select: { jobNumber: true, title: true, clientName: true, status: true } } }, orderBy: { assignedAt: 'desc' } }),
  ]);
  const totalAdvances = advances.reduce((s, a) => s + a.amount, 0);
  const totalWages = payments.filter(p => p.type === 'WAGE' || p.type === 'BONUS').reduce((s, p) => s + p.amount, 0);
  const totalDeductions = payments.filter(p => p.type === 'DEDUCTION').reduce((s, p) => s + p.amount, 0);
  ok(res, { worker, advances, payments, jobs, summary: { totalAdvances, totalWages, totalDeductions, netBalance: totalAdvances - totalWages + totalDeductions } });
}));

// ============================================================
// JOB CARDS
// ============================================================
router.get('/jobs', asyncHandler(async (req, res) => {
  const { status, workerId, search, take = '50' } = req.query;
  const jobs = await prisma.jobCard.findMany({
    where: { deletedAt: null, ...(status ? { status: status as string } : {}), ...(workerId ? { assignments: { some: { workerId: workerId as string } } } : {}), ...(search ? { OR: [{ title: { contains: search as string, mode: 'insensitive' } }, { clientName: { contains: search as string, mode: 'insensitive' } }, { jobNumber: { contains: search as string } }] } : {}) },
    take: parseInt(take as string), orderBy: { createdAt: 'desc' },
    include: { assignments: { include: { worker: { select: { fullName: true, phone: true } } } }, clientPayments: true, materials: true },
  });
  ok(res, jobs);
}));

router.get('/jobs/:id', asyncHandler(async (req, res) => {
  const job = await prisma.jobCard.findFirst({ where: { id: req.params.id, deletedAt: null }, include: { assignments: { include: { worker: true } }, clientPayments: true, materials: true } });
  if (!job) throw ApiError.notFound('Job not found');
  ok(res, job);
}));

router.post('/jobs', asyncHandler(async (req, res) => {
  const { title, description, clientName, clientPhone, clientAddress, jobType, scheduledDate, priority, estimatedHours, laborCost, notes, workerIds } = req.body;
  const job = await prisma.jobCard.create({
    data: { jobNumber: `JOB-${Date.now()}`, title, description, clientName, clientPhone, clientAddress, jobType, priority, notes, estimatedHours: parseInt(estimatedHours) || 0, laborCost: Math.round((parseFloat(laborCost) || 0) * 100), totalCharged: Math.round((parseFloat(laborCost) || 0) * 100), scheduledDate: scheduledDate ? new Date(scheduledDate) : null, createdBy: req.user!.id, assignments: workerIds?.length ? { create: workerIds.map((wid: string, i: number) => ({ workerId: wid, role: i === 0 ? 'lead' : 'worker' })) } : undefined },
    include: { assignments: { include: { worker: true } } },
  });
  created(res, job);
}));

router.put('/jobs/:id', asyncHandler(async (req, res) => {
  const { title, description, clientName, clientPhone, clientAddress, jobType, scheduledDate, priority, estimatedHours, laborCost, materialCost, notes, status } = req.body;
  const data: any = { title, description, clientName, clientPhone, clientAddress, jobType, priority, notes, status };
  if (scheduledDate) data.scheduledDate = new Date(scheduledDate);
  if (estimatedHours !== undefined) data.estimatedHours = parseInt(estimatedHours);
  if (laborCost !== undefined) data.laborCost = Math.round(parseFloat(laborCost) * 100);
  if (materialCost !== undefined) data.materialCost = Math.round(parseFloat(materialCost) * 100);
  if (status === 'IN_PROGRESS') data.startedAt = new Date();
  if (status === 'COMPLETED') data.completedAt = new Date();
  data.totalCharged = (data.laborCost ?? 0) + (data.materialCost ?? 0);
  const job = await prisma.jobCard.update({ where: { id: req.params.id }, data, include: { assignments: { include: { worker: true } }, clientPayments: true } });
  ok(res, job, 'Updated');
}));

router.patch('/jobs/:id/worklog', asyncHandler(async (req, res) => {
  const { assignmentId, workDone, hoursWorked, status } = req.body;
  const assignment = await prisma.jobAssignment.update({ where: { id: assignmentId }, data: { workDone, hoursWorked: parseInt(hoursWorked) || 0, status, ...(status === 'COMPLETED' ? { completedAt: new Date() } : {}) } });
  ok(res, assignment, 'Work log updated');
}));

router.post('/jobs/:id/materials', asyncHandler(async (req, res) => {
  const { description, quantity, unitCost, productId } = req.body;
  const uc = Math.round(parseFloat(unitCost) * 100);
  const material = await prisma.jobMaterial.create({ data: { jobId: req.params.id, description, quantity: parseInt(quantity), unitCost: uc, totalCost: uc * parseInt(quantity), productId: productId || null } });
  const allMaterials = await prisma.jobMaterial.findMany({ where: { jobId: req.params.id } });
  const totalMaterial = allMaterials.reduce((s, m) => s + m.totalCost, 0);
  await prisma.jobCard.update({ where: { id: req.params.id }, data: { materialCost: totalMaterial, totalCharged: { increment: material.totalCost } } });
  ok(res, material, 'Material added');
}));

router.post('/jobs/:id/payments', asyncHandler(async (req, res) => {
  const { amount, method, reference, note } = req.body;
  const amt = Math.round(parseFloat(amount) * 100);
  const payment = await prisma.jobClientPayment.create({ data: { jobId: req.params.id, amount: amt, method, reference, note, receivedBy: req.user!.id } });
  await prisma.jobCard.update({ where: { id: req.params.id }, data: { totalReceived: { increment: amt } } });
  ok(res, payment, 'Payment recorded');
}));

router.get('/stats', asyncHandler(async (req, res) => {
  const [totalJobs, pendingJobs, inProgressJobs, completedJobs, totalWorkers, recentJobs] = await Promise.all([
    prisma.jobCard.count({ where: { deletedAt: null } }),
    prisma.jobCard.count({ where: { deletedAt: null, status: 'PENDING' } }),
    prisma.jobCard.count({ where: { deletedAt: null, status: 'IN_PROGRESS' } }),
    prisma.jobCard.count({ where: { deletedAt: null, status: 'COMPLETED' } }),
    prisma.worker.count({ where: { deletedAt: null, isActive: true } }),
    prisma.jobCard.findMany({ where: { deletedAt: null }, take: 5, orderBy: { createdAt: 'desc' }, include: { assignments: { include: { worker: { select: { fullName: true } } } } } }),
  ]);
  const payments = await prisma.jobClientPayment.findMany({ select: { amount: true } });
  const totalRevenue = payments.reduce((s, p) => s + p.amount, 0);
  ok(res, { totalJobs, pendingJobs, inProgressJobs, completedJobs, totalWorkers, totalRevenue, recentJobs });
}));

export default router;
