import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok } from '../../utils/response';
import { prisma } from '../../config/prisma';

export const reportsRouter = Router();
reportsRouter.use(authenticate);

// Sales summary by date range
reportsRouter.get('/sales-summary', requirePermission('reports', 'read'), asyncHandler(async (req, res) => {
  const { from, to, branchId } = req.query;
  const start = from ? new Date(from as string) : new Date(new Date().setDate(new Date().getDate() - 30));
  const end = to ? new Date(to as string) : new Date();
  end.setHours(23, 59, 59, 999);

  const sales = await prisma.sale.findMany({
    where: { status: 'COMPLETED', createdAt: { gte: start, lte: end }, ...(branchId ? { branchId: branchId as string } : {}) },
    include: { payments: true, lineItems: true },
  });

  const byDay: Record<string, { revenue: number; count: number }> = {};
  for (const sale of sales) {
    const day = sale.createdAt.toISOString().slice(0, 10);
    if (!byDay[day]) byDay[day] = { revenue: 0, count: 0 };
    byDay[day].revenue += sale.grandTotal;
    byDay[day].count += 1;
  }

  const byPayment: Record<string, number> = {};
  for (const sale of sales) {
    for (const p of sale.payments) {
      byPayment[p.method] = (byPayment[p.method] ?? 0) + p.amount;
    }
  }

  ok(res, {
    totalRevenue: sales.reduce((s, x) => s + x.grandTotal, 0),
    totalTransactions: sales.length,
    avgBill: sales.length ? Math.round(sales.reduce((s, x) => s + x.grandTotal, 0) / sales.length) : 0,
    totalDiscount: sales.reduce((s, x) => s + x.billDiscount + x.lineDiscount, 0),
    byDay: Object.entries(byDay).sort((a, b) => a[0].localeCompare(b[0])).map(([date, v]) => ({ date, ...v })),
    byPaymentMethod: Object.entries(byPayment).map(([method, amount]) => ({ method, amount })),
  });
}));

// Inventory valuation
reportsRouter.get('/inventory-valuation', requirePermission('reports', 'read'), asyncHandler(async (_req, res) => {
  const stock = await prisma.warehouseStock.findMany({
    include: { product: { select: { name: true, sku: true, costPrice: true, sellingPrice: true } }, warehouse: { select: { name: true } } },
  });
  const rows = stock.map((s) => ({
    product: s.product.name, sku: s.product.sku, warehouse: s.warehouse.name,
    quantity: s.quantity, costPrice: s.product.costPrice, sellingPrice: s.product.sellingPrice,
    costValue: s.quantity * s.product.costPrice, retailValue: s.quantity * s.product.sellingPrice,
    potentialProfit: s.quantity * (s.product.sellingPrice - s.product.costPrice),
  }));
  ok(res, { rows, totalCostValue: rows.reduce((s, r) => s + r.costValue, 0), totalRetailValue: rows.reduce((s, r) => s + r.retailValue, 0) });
}));

// Top products
reportsRouter.get('/top-products', requirePermission('reports', 'read'), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const start = from ? new Date(from as string) : new Date(new Date().setDate(new Date().getDate() - 30));
  const end = to ? new Date(to as string) : new Date();
  const lines = await prisma.saleLineItem.findMany({
    where: { sale: { createdAt: { gte: start, lte: end }, status: 'COMPLETED' } },
    include: { product: { select: { name: true, sku: true } } },
  });
  const map: Record<string, { name: string; sku: string; qty: number; revenue: number }> = {};
  for (const l of lines) {
    if (!map[l.productId]) map[l.productId] = { name: l.product.name, sku: l.product.sku, qty: 0, revenue: 0 };
    map[l.productId].qty += l.quantity;
    map[l.productId].revenue += l.lineTotal;
  }
  ok(res, Object.values(map).sort((a, b) => b.revenue - a.revenue).slice(0, 20));
}));

// Cashier performance
reportsRouter.get('/cashier-performance', requirePermission('reports', 'read'), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const start = from ? new Date(from as string) : new Date(new Date().setDate(new Date().getDate() - 30));
  const end = to ? new Date(to as string) : new Date();
  const sales = await prisma.sale.findMany({
    where: { status: 'COMPLETED', createdAt: { gte: start, lte: end } },
    include: { user: { select: { fullName: true, email: true } } },
  });
  const map: Record<string, { name: string; email: string; sales: number; revenue: number; discounts: number }> = {};
  for (const s of sales) {
    const uid = s.userId;
    if (!map[uid]) map[uid] = { name: s.user.fullName, email: s.user.email, sales: 0, revenue: 0, discounts: 0 };
    map[uid].sales += 1;
    map[uid].revenue += s.grandTotal;
    map[uid].discounts += s.billDiscount + s.lineDiscount;
  }
  ok(res, Object.values(map).sort((a, b) => b.revenue - a.revenue));
}));

// Finance router
export const financeRouter = Router();
financeRouter.use(authenticate);

// Expenses
financeRouter.get('/expenses', requirePermission('finance', 'read'), asyncHandler(async (req, res) => {
  const expenses = await prisma.expense.findMany({ orderBy: { expenseDate: 'desc' }, take: 100 });
  ok(res, expenses);
}));

financeRouter.post('/expenses', requirePermission('finance', 'create'), asyncHandler(async (req, res) => {
  const { category, amount, description, expenseDate } = req.body;
  const expense = await prisma.expense.create({
    data: { category, amount, description, expenseDate: expenseDate ? new Date(expenseDate) : new Date(), createdBy: req.user!.id },
  });
  ok(res, expense);
}));

financeRouter.patch('/expenses/:id/approve', requirePermission('finance', 'approve'), asyncHandler(async (req, res) => {
  const expense = await prisma.expense.update({
    where: { id: req.params.id },
    data: { status: 'APPROVED', approvedBy: req.user!.id },
  });
  ok(res, expense, 'Approved');
}));

// P&L summary
financeRouter.get('/pnl', requirePermission('finance', 'read'), asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const start = from ? new Date(from as string) : new Date(new Date().setDate(new Date().getDate() - 30));
  const end = to ? new Date(to as string) : new Date();
  end.setHours(23, 59, 59, 999);

  const [sales, expenses] = await Promise.all([
    prisma.sale.findMany({ where: { status: 'COMPLETED', createdAt: { gte: start, lte: end } }, include: { lineItems: true } }),
    prisma.expense.findMany({ where: { status: 'APPROVED', expenseDate: { gte: start, lte: end } } }),
  ]);

  const revenue = sales.reduce((s, x) => s + x.grandTotal, 0);
  const cogs = sales.reduce((s, sale) => s + sale.lineItems.reduce((ls, l) => ls + l.lineTotal, 0), 0);
  const grossProfit = revenue - cogs;
  const totalExpenses = expenses.reduce((s, e) => s + e.amount, 0);
  const netProfit = grossProfit - totalExpenses;

  ok(res, { revenue, cogs, grossProfit, grossMargin: revenue ? Math.round((grossProfit / revenue) * 10000) : 0, totalExpenses, netProfit, period: { from: start, to: end } });
}));

// Audit logs
financeRouter.get('/audit-logs', requirePermission('finance', 'read'), asyncHandler(async (req, res) => {
  const { module, userId, take = '50' } = req.query;
  const logs = await prisma.auditLog.findMany({
    where: {
      ...(module ? { module: module as string } : {}),
      ...(userId ? { userId: userId as string } : {}),
    },
    take: parseInt(take as string),
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { fullName: true, email: true } } },
  });
  ok(res, logs);
}));
