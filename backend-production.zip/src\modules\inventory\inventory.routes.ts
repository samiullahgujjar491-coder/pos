import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { prisma } from '../../config/prisma';
import { z } from 'zod';
import { validate } from '../../middleware/validate';
import { auditLogger } from '../../middleware/auditLogger';

const router = Router();
router.use(authenticate, auditLogger('inventory'));

// GET all warehouse stock
router.get('/stock', requirePermission('inventory', 'read'), asyncHandler(async (req, res) => {
  const products = await prisma.product.findMany({
    where: { deletedAt: null, isActive: true },
    include: {
      warehouseStock: { include: { warehouse: { select: { name: true } } } },
    },
    orderBy: { name: 'asc' },
  });

  const mainWh = await prisma.warehouse.findFirst();
  
  const stockList = [];
  for (const p of products) {
    if (p.warehouseStock.length > 0) {
      for (const ws of p.warehouseStock) {
        stockList.push({ id: ws.id, quantity: ws.quantity, product: p, warehouse: ws.warehouse });
      }
    } else {
      stockList.push({ id: `0-stock-${p.id}`, quantity: 0, product: p, warehouse: mainWh || { name: 'Main Warehouse' } });
    }
  }
  
  ok(res, stockList);
}));

// LOW STOCK alert list
router.get('/stock/low', requirePermission('inventory', 'read'), asyncHandler(async (req, res) => {
  const stock = await prisma.warehouseStock.findMany({
    include: { product: true, warehouse: { select: { name: true } } },
  });
  const low = stock.filter((s) => s.quantity <= s.product.reorderPoint && s.product.isActive);
  ok(res, low);
}));

// STOCK MOVEMENTS for a product
router.get('/movements', requirePermission('inventory', 'read'), asyncHandler(async (req, res) => {
  const { productId, warehouseId, type, take = '50' } = req.query;
  const movements = await prisma.stockMovement.findMany({
    where: {
      ...(productId ? { productId: productId as string } : {}),
      ...(warehouseId ? { warehouseId: warehouseId as string } : {}),
      ...(type ? { type: type as string } : {}),
    },
    take: parseInt(take as string),
    orderBy: { createdAt: 'desc' },
    include: { product: { select: { name: true, sku: true } }, warehouse: { select: { name: true } } },
  });
  ok(res, movements);
}));

// ADJUSTMENT
const adjustSchema = z.object({
  body: z.object({
    productId: z.string().uuid(),
    warehouseId: z.string().uuid(),
    quantity: z.number().int(), // signed
    reason: z.string().min(1),
  }),
});
router.post('/adjust', requirePermission('inventory', 'update'), validate(adjustSchema), asyncHandler(async (req, res) => {
  const { productId, warehouseId, quantity, reason } = req.body;
  let ws = await prisma.warehouseStock.findFirst({
    where: { warehouseId, productId, variantId: null }
  });
  if (ws) {
    await prisma.warehouseStock.update({
      where: { id: ws.id },
      data: { quantity: { increment: quantity } }
    });
  } else {
    await prisma.warehouseStock.create({
      data: { warehouseId, productId, quantity: Math.max(0, quantity) }
    });
  }
  const movement = await prisma.stockMovement.create({
    data: { productId, warehouseId, type: 'ADJUSTMENT', quantity, reason, createdBy: req.user!.id },
  });
  ok(res, movement, 'Stock adjusted');
}));

// WAREHOUSES list
router.get('/warehouses', requirePermission('inventory', 'read'), asyncHandler(async (_req, res) => {
  const warehouses = await prisma.warehouse.findMany({
    where: { deletedAt: null },
    include: { branch: { select: { name: true } } },
  });
  ok(res, warehouses);
}));

// STOCK TRANSFER
const transferSchema = z.object({
  body: z.object({
    fromWhId: z.string().uuid(),
    toWhId: z.string().uuid(),
    notes: z.string().optional(),
    lineItems: z.array(z.object({ productId: z.string().uuid(), quantity: z.number().int().positive() })).min(1),
  }),
});
router.post('/transfer', requirePermission('inventory', 'create'), validate(transferSchema), asyncHandler(async (req, res) => {
  const { fromWhId, toWhId, notes, lineItems } = req.body;
  const ref = `TRF-${Date.now()}`;
  const transfer = await prisma.stockTransfer.create({
    data: {
      reference: ref, fromWhId, toWhId, notes, status: 'RECEIVED', createdBy: req.user!.id,
      lineItems: { create: lineItems },
    },
  });
  // Move stock
  for (const line of lineItems) {
    await prisma.warehouseStock.updateMany({ where: { warehouseId: fromWhId, productId: line.productId }, data: { quantity: { decrement: line.quantity } } });
    let toWs = await prisma.warehouseStock.findFirst({
      where: { warehouseId: toWhId, productId: line.productId, variantId: null }
    });
    if (toWs) {
      await prisma.warehouseStock.update({
        where: { id: toWs.id },
        data: { quantity: { increment: line.quantity } }
      });
    } else {
      await prisma.warehouseStock.create({
        data: { warehouseId: toWhId, productId: line.productId, quantity: line.quantity }
      });
    }
    await prisma.stockMovement.createMany({
      data: [
        { productId: line.productId, warehouseId: fromWhId, type: 'TRANSFER_OUT', quantity: -line.quantity, reference: transfer.id, createdBy: req.user!.id },
        { productId: line.productId, warehouseId: toWhId, type: 'TRANSFER_IN', quantity: line.quantity, reference: transfer.id, createdBy: req.user!.id },
      ],
    });
  }
  ok(res, transfer, 'Transfer completed');
}));

export default router;
