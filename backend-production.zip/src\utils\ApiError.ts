export class ApiError extends Error {
  statusCode: number;
  code: string;
  errors?: unknown;
  constructor(statusCode: number, message: string, code = 'ERROR', errors?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.errors = errors;
  }
  static badRequest(msg: string, errors?: unknown) { return new ApiError(400, msg, 'BAD_REQUEST', errors); }
  static unauthorized(msg = 'Unauthorized') { return new ApiError(401, msg, 'UNAUTHORIZED'); }
  static forbidden(msg = 'Forbidden') { return new ApiError(403, msg, 'FORBIDDEN'); }
  static notFound(msg = 'Not found') { return new ApiError(404, msg, 'NOT_FOUND'); }
  static conflict(msg: string) { return new ApiError(409, msg, 'CONFLICT'); }
}
