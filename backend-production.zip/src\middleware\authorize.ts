import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/ApiError';

// requirePermission('products', 'create')
export const requirePermission =
  (module: string, action: string) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) throw ApiError.unauthorized();
    const needed = `${module}:${action}`;
    // Super Admin shortcut
    if (req.user.roleName === 'Super Admin' || req.user.permissions.includes(needed)) {
      return next();
    }
    throw ApiError.forbidden(`Missing permission: ${needed}`);
  };
