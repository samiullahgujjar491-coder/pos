import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';

// Logs every successful mutating request (POST/PUT/PATCH/DELETE)
export function auditLogger(module: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const mutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
    if (!mutating) return next();
    res.on('finish', () => {
      if (res.statusCode < 400) {
        prisma.auditLog.create({
          data: {
            userId: req.user?.id ?? null,
            module,
            action: req.method,
            recordId: (req.params as any).id ?? null,
            afterData: req.body ?? undefined,
            ipAddress: req.ip,
          },
        }).catch((e) => console.error('Audit log failed:', e));
      }
    });
    next();
  };
}
