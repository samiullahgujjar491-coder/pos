import { prisma } from '../../config/prisma';
import { ApiError } from '../../utils/ApiError';
import { Prisma } from '@prisma/client';

interface ListParams {
  search?: string;
  categoryId?: string;
  cursor?: string;
  take?: number;
}

export const productService = {
  async list({ search, categoryId, cursor, take = 25 }: ListParams) {
    const where: Prisma.ProductWhereInput = {
      deletedAt: null,
      ...(categoryId ? { categoryId } : {}),
      ...(search
        ? {
            OR: [
              { name: { contains: search, mode: 'insensitive' } },
              { sku: { contains: search, mode: 'insensitive' } },
              { barcode: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {}),
    };
    const items = await prisma.product.findMany({
      where,
      take: take + 1,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      orderBy: { createdAt: 'desc' },
      include: { category: true, images: true, variants: true, warehouseStock: true },
    });
    const hasMore = items.length > take;
    const data = hasMore ? items.slice(0, take) : items;
    return { items: data, nextCursor: hasMore ? data[data.length - 1].id : null };
  },

  async getById(id: string) {
    const product = await prisma.product.findFirst({
      where: { id, deletedAt: null },
      include: { category: true, images: true, variants: true, warehouseStock: true },
    });
    if (!product) throw ApiError.notFound('Product not found');
    return product;
  },

  async create(data: Prisma.ProductCreateInput, userId?: string) {
    if (data.barcode === '') data.barcode = null;
    if (data.categoryId === '') data.categoryId = null;
    if (data.brand === '') data.brand = null;

    const exists = await prisma.product.findFirst({ where: { sku: data.sku, deletedAt: null } });
    if (exists) throw ApiError.conflict(`SKU ${data.sku} already exists`);

    if (data.barcode) {
      const barcodeExists = await prisma.product.findFirst({ where: { barcode: data.barcode, deletedAt: null } });
      if (barcodeExists) throw ApiError.conflict(`Barcode ${data.barcode} already exists`);
    }

    return prisma.product.create({ data: { ...data, createdBy: userId } });
  },

  async update(id: string, data: Prisma.ProductUpdateInput) {
    if (data.barcode === '') data.barcode = null;
    if (data.categoryId === '') data.categoryId = null;
    if (data.brand === '') data.brand = null;

    if (data.sku) {
      const exists = await prisma.product.findFirst({ where: { sku: data.sku as string, id: { not: id }, deletedAt: null } });
      if (exists) throw ApiError.conflict(`SKU ${data.sku} already exists`);
    }

    if (data.barcode) {
      const barcodeExists = await prisma.product.findFirst({ where: { barcode: data.barcode as string, id: { not: id }, deletedAt: null } });
      if (barcodeExists) throw ApiError.conflict(`Barcode ${data.barcode} already exists`);
    }

    await this.getById(id);
    return prisma.product.update({ where: { id }, data });
  },

  async remove(id: string) {
    await this.getById(id);
    return prisma.product.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
  },
};
