import http from 'http';
import { createApp } from './app';
import { env } from './config/env';
import { initSocket } from './config/socket';
import { prisma } from './config/prisma';

async function main() {
  const app = createApp();
  const server = http.createServer(app);
  initSocket(server);
  server.listen(env.port, () => {
    console.log(`POS API running on http://localhost:${env.port}`);
    console.log(`Swagger docs at http://localhost:${env.port}/api-docs`);
  });
  const shutdown = async () => { await prisma.$disconnect(); server.close(() => process.exit(0)); };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}
main().catch((e) => { console.error(e); process.exit(1); });
