import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { ApiError } from '../utils/ApiError';

export function authenticate(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) throw ApiError.unauthorized('Missing access token');
  const token = header.slice(7);
  try {
    req.user = jwt.verify(token, env.jwtSecret) as Express.UserPayload;
    next();
  } catch {
    throw ApiError.unauthorized('Invalid or expired token');
  }
}
