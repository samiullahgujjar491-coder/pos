import { Server as HttpServer } from 'http';
import { Server } from 'socket.io';
import { env } from './env';

let io: Server | null = null;

export function initSocket(httpServer: HttpServer) {
  io = new Server(httpServer, { cors: { origin: env.corsOrigin } });
  io.on('connection', (socket) => {
    // Terminals join their warehouse channel to receive inventory updates
    socket.on('join:warehouse', (warehouseId: string) => socket.join(`wh:${warehouseId}`));
    socket.on('disconnect', () => {});
  });
  return io;
}

// Broadcast an inventory change to all terminals on a warehouse channel.
// Prevents overselling of low-stock items across multiple cashiers.
export function emitInventoryChange(warehouseId: string, payload: unknown) {
  io?.to(`wh:${warehouseId}`).emit('inventory:changed', payload);
}
