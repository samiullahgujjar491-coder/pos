import { z } from 'zod';

const valuation = z.enum(['FIFO', 'LIFO', 'WEIGHTED_AVG']);

const emptyToUndefined = z.union([z.string(), z.literal('')]).optional().transform(e => e === '' ? undefined : e);
const uuidEmptyToUndefined = z.union([z.string().uuid(), z.literal('')]).optional().transform(e => e === '' ? undefined : e);

export const createProductSchema = z.object({
  body: z.object({
    name: z.string().min(1),
    sku: z.string().min(1),
    barcode: emptyToUndefined,
    description: emptyToUndefined,
    categoryId: uuidEmptyToUndefined,
    brand: emptyToUndefined,
    baseUnit: z.string().default('piece'),
    valuationMethod: valuation.default('WEIGHTED_AVG'),
    costPrice: z.number().int().nonnegative().default(0),
    sellingPrice: z.number().int().nonnegative().default(0),
    reorderPoint: z.number().int().nonnegative().default(0),
    reorderQty: z.number().int().nonnegative().default(0),
    maxStock: z.number().int().nonnegative().optional(),
    trackBatches: z.boolean().default(false),
    trackSerials: z.boolean().default(false),
  }),
});

export const updateProductSchema = z.object({
  body: createProductSchema.shape.body.partial(),
});

