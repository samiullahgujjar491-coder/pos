import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import { ApiError } from '../utils/ApiError';

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(400).json({
      success: false, message: 'Validation failed', code: 'VALIDATION_ERROR',
      errors: err.flatten().fieldErrors,
    });
  }
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      success: false, message: err.message, code: err.code, errors: err.errors ?? null,
    });
  }
  console.error('Unhandled error:', err);
  return res.status(500).json({
    success: false, message: 'Internal server error', code: 'INTERNAL_ERROR', errors: null,
  });
}
