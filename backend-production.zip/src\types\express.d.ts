import 'express';
declare global {
  namespace Express {
    interface UserPayload {
      id: string;
      email: string;
      roleId: string;
      roleName: string;
      permissions: string[]; // "module:action"
      branchIds: string[];
    }
    interface Request {
      user?: UserPayload;
    }
  }
}
export {};
