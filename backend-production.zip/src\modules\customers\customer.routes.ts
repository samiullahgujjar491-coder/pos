import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { prisma } from '../../config/prisma';
import { ApiError } from '../../utils/ApiError';
import { z } from 'zod';
import { validate } from '../../middleware/validate';
import { auditLogger } from '../../middleware/auditLogger';

const router = Router();
router.use(authenticate, auditLogger('crm'));

const customerSchema = z.object({
  body: z.object({
    name: z.string().min(1),
    email: z.string().email().optional().or(z.literal('')),
    phone: z.string().optional(),
    address: z.string().optional(),
    dob: z.string().optional(),
    segment: z.string().optional(),
    priceTier: z.enum(['RETAIL', 'WHOLESALE', 'VIP']).default('RETAIL'),
    notes: z.string().optional(),
  }),
});

// LIST
router.get('/', requirePermission('crm', 'read'), asyncHandler(async (req, res) => {
  const { search, segment, take = '50', cursor } = req.query;
  const where: any = { deletedAt: null };
  if (search) where.OR = [
    { name: { contains: search, mode: 'insensitive' } },
    { phone: { contains: search as string } },
    { email: { contains: search, mode: 'insensitive' } },
  ];
  if (segment) where.segment = segment;

  const items = await prisma.customer.findMany({
    where, take: parseInt(take as string) + 1,
    ...(cursor ? { cursor: { id: cursor as string }, skip: 1 } : {}),
    orderBy: { createdAt: 'desc' },
    include: { loyalty: true, credit: true, _count: { select: { sales: true } } },
  });
  const hasMore = items.length > parseInt(take as string);
  ok(res, { items: hasMore ? items.slice(0, parseInt(take as string)) : items, nextCursor: hasMore ? items[parseInt(take as string) - 1].id : null });
}));

// GET BY ID with full purchase history
router.get('/:id', requirePermission('crm', 'read'), asyncHandler(async (req, res) => {
  const customer = await prisma.customer.findFirst({
    where: { id: req.params.id, deletedAt: null },
    include: {
      loyalty: true, credit: true,
      sales: { orderBy: { createdAt: 'desc' }, take: 20, include: { lineItems: true, payments: true } },
    },
  });
  if (!customer) throw ApiError.notFound('Customer not found');
  ok(res, customer);
}));

// CREATE
router.post('/', requirePermission('crm', 'create'), validate(customerSchema), asyncHandler(async (req, res) => {
  const { name, email, phone, address, dob, segment, priceTier, notes } = req.body;
  const customer = await prisma.customer.create({
    data: {
      name, phone, address, segment, priceTier, notes,
      email: email || null,
      dob: dob ? new Date(dob) : null,
      createdBy: req.user!.id,
      loyalty: { create: { pointsBalance: 0, lifetimePoints: 0 } },
      credit: { create: { creditLimit: 0, outstanding: 0 } },
    },
    include: { loyalty: true, credit: true },
  });
  created(res, customer);
}));

// UPDATE
router.put('/:id', requirePermission('crm', 'update'), validate(customerSchema), asyncHandler(async (req, res) => {
  const { name, email, phone, address, dob, segment, priceTier, notes } = req.body;
  const customer = await prisma.customer.update({
    where: { id: req.params.id },
    data: { name, phone, address, segment, priceTier, notes, email: email || null, dob: dob ? new Date(dob) : null },
  });
  ok(res, customer, 'Updated');
}));

// UPDATE CREDIT LIMIT
router.patch('/:id/credit', requirePermission('crm', 'update'), asyncHandler(async (req, res) => {
  const { creditLimit } = req.body;
  await prisma.customerCredit.upsert({
    where: { customerId: req.params.id },
    update: { creditLimit },
    create: { customerId: req.params.id, creditLimit, outstanding: 0 },
  });
  ok(res, null, 'Credit limit updated');
}));

// DELETE (soft)
router.delete('/:id', requirePermission('crm', 'delete'), asyncHandler(async (req, res) => {
  await prisma.customer.update({ where: { id: req.params.id }, data: { deletedAt: new Date() } });
  ok(res, null, 'Deleted');
}));

export default router;
