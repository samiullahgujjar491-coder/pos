import { Router } from 'express';
import { productController } from './product.controller';
import { validate } from '../../middleware/validate';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { auditLogger } from '../../middleware/auditLogger';
import { createProductSchema, updateProductSchema } from './product.schema';

const router = Router();
router.use(authenticate, auditLogger('products'));

router.get('/', requirePermission('products', 'read'), productController.list);
router.get('/:id', requirePermission('products', 'read'), productController.get);
router.post('/', requirePermission('products', 'create'), validate(createProductSchema), productController.create);
router.put('/:id', requirePermission('products', 'update'), validate(updateProductSchema), productController.update);
router.delete('/:id', requirePermission('products', 'delete'), productController.remove);
export default router;
