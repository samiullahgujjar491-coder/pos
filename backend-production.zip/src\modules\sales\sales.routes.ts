import { Router } from 'express';
import { authenticate } from '../../middleware/auth';
import { requirePermission } from '../../middleware/authorize';
import { asyncHandler } from '../../utils/asyncHandler';
import { ok, created } from '../../utils/response';
import { salesService } from './sales.service';
import { z } from 'zod';
import { validate } from '../../middleware/validate';

const router = Router();
router.use(authenticate);

const createSaleSchema = z.object({
  body: z.object({
    branchId: z.string().uuid(),
    terminalId: z.string().uuid().optional(),
    customerId: z.string().uuid().optional(),
    billDiscount: z.number().int().nonnegative().default(0),
    currency: z.string().default('PKR'),
    lineItems: z.array(z.object({
      productId: z.string().uuid(),
      description: z.string(),
      quantity: z.number().int().positive(),
      unitPrice: z.number().int().nonnegative(),
      discount: z.number().int().nonnegative().default(0),
      taxRate: z.number().int().nonnegative().default(1700),
    })).min(1),
    payments: z.array(z.object({
      method: z.enum(['CASH', 'CARD', 'WALLET', 'CREDIT', 'SPLIT']),
      amount: z.number().int().positive(),
      reference: z.string().optional(),
    })).min(1),
  }),
});

router.post('/', requirePermission('pos', 'create'), validate(createSaleSchema), asyncHandler(async (req, res) => {
  created(res, await salesService.create(req.body, req.user!.id));
}));

router.get('/', requirePermission('pos', 'read'), asyncHandler(async (req, res) => {
  const { branchId, take, cursor } = req.query;
  ok(res, await salesService.list(branchId as string, take ? parseInt(take as string) : 50, cursor as string));
}));

router.get('/stats/today', requirePermission('pos', 'read'), asyncHandler(async (req, res) => {
  const branchId = req.query.branchId as string ?? req.user!.branchIds[0];
  ok(res, await salesService.todayStats(branchId));
}));

router.get('/:id', requirePermission('pos', 'read'), asyncHandler(async (req, res) => {
  ok(res, await salesService.getById(req.params.id));
}));

export default router;
