import { Router } from 'express';
import { authController } from './auth.controller';
import { validate } from '../../middleware/validate';
import { authenticate } from '../../middleware/auth';
import { authLimiter } from '../../middleware/rateLimiter';
import { loginSchema, pinLoginSchema, refreshSchema } from './auth.schema';

const router = Router();
router.post('/login', authLimiter, validate(loginSchema), authController.login);
router.post('/pin-login', authLimiter, validate(pinLoginSchema), authController.pinLogin);
router.post('/refresh', validate(refreshSchema), authController.refresh);
router.post('/logout', authController.logout);
router.get('/me', authenticate, authController.me);
export default router;
