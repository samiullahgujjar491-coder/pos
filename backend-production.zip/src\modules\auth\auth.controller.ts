import { Request, Response } from 'express';
import { authService } from './auth.service';
import { ok } from '../../utils/response';
import { asyncHandler } from '../../utils/asyncHandler';

export const authController = {
  login: asyncHandler(async (req: Request, res: Response) => {
    const { email, password } = req.body;
    ok(res, await authService.login(email, password), 'Logged in');
  }),
  pinLogin: asyncHandler(async (req: Request, res: Response) => {
    const { email, pin } = req.body;
    ok(res, await authService.pinLogin(email, pin), 'Logged in');
  }),
  refresh: asyncHandler(async (req: Request, res: Response) => {
    ok(res, await authService.refresh(req.body.refreshToken), 'Token refreshed');
  }),
  logout: asyncHandler(async (req: Request, res: Response) => {
    await authService.logout(req.body.refreshToken);
    ok(res, null, 'Logged out');
  }),
  me: asyncHandler(async (req: Request, res: Response) => {
    ok(res, req.user, 'Current user');
  }),
};
